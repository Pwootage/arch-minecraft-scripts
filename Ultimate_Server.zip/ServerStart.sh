java -Xms512M -Xmx1G -jar ftbserver.jar
